---
layout: page
title: Publications
subtitle:
---

The full list of publications can be found on <a href="https://scholar.google.com.au/citations?user=XQViiyYAAAAJ&hl=en" target="_blank">Google Scholar</a>.

### 2026

<a href="https://arxiv.org/abs/2603.23509" target="_blank"><b>	
Internal Safety Collapse in Frontier Large Language Models
</b></a> <a href="https://github.com/wuyoscar/ISC-Bench" target="_blank"> [Code] </a> <br/>
Yutao Wu, Xiao Liu, Hanxun Huang, Yige Li, Xiang Zheng, Yifeng Gao, Cong Wang, Bo Li, **Xingjun Ma**, Yu-Gang Jiang
<br/>
Annual Conference on Neural Information Processing Systems (<b>NeurIPS</b>), Sydney, Australia, 2026.

<a href="https://arxiv.org/abs/2609.35028" target="_blank"><b>	
VEX-Bench: Benchmarking Verification Complexity of LLM-Generated Misinformation
</b></a> <a href="https://github.com/HanxunH/VEX-Bench" target="_blank"> [Code] </a> <br/>
Hanxun Huang, Yutao Wu, Qizhou Wang, Silvia Montaña-Niño, Yige Li, Xiang Zheng, Elif Buse Doyuran, Phoebe Matich, Xiao Liu, **Xingjun Ma**, Sarah Erfani, Christopher Leckie
<br/>
Annual Conference on Neural Information Processing Systems (<b>NeurIPS</b>), Sydney, Australia, 2026.

<a href="" target="_blank"><b>	
ShadowFPT: Backdooring Federated Prompt Tuning via Shadow Triggers
</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Kun Zhai, Teng Li, Yunhao Feng, **Xingjun Ma**
<br/>
Annual Conference on Neural Information Processing Systems (<b>NeurIPS</b>), Sydney, Australia, 2026.

<a href="https://openreview.net/forum?id=Y02g0k3yX4#discussion" target="_blank"><b>	
Towards Multi-Human-Value Alignment via Value Localization in LLMs
</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Xueqi Ma, Yanbei Jiang, **Xingjun Ma**, James Bailey, Sarah Erfani
<br/>
Annual Conference on Neural Information Processing Systems (<b>NeurIPS</b>), Sydney, Australia, 2026.


<a href="https://arxiv.org/abs/2604.02947" target="_blank"><b>	
AgentHazard: A Benchmark for Evaluating Harmful Behavior in Computer-Use Agents
</b></a> <a href="https://github.com/Yunhao-Feng/AgentHazard" target="_blank"> [Code] </a> <br/>
Yifan Ding, Yunhao Feng, Yifeng Gao, Yige Li, Yutao Wu, Yanming Guo, Yingshui Tan, Kun Zhai, **Xingjun Ma**
<br/>
ACM Multimedia (<b>MM</b>), Rio de Janeiro, Brazil, 2026.

<a href="https://arxiv.org/abs/2503.06223" target="_blank"><b>	
RedDiffuser: Auditing Multimodal Safety Failures in Vision-Language Models via Reinforced Diffusion
</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Ruofan Wang, **Xingjun Ma**
<br/>
ACM Multimedia (<b>MM</b>), Rio de Janeiro, Brazil, 2026.

<a href="https://arxiv.org/abs/2511.18921" target="_blank"><b>	
BackdoorVLM: A Benchmark for Backdoor Attacks and Defenses on Vision-Language Models
</b></a> <a href="https://github.com/bin015/BackdoorVLM" target="_blank"> [Code] </a> <br/>
Juncheng Li, Yige Li, Hanxun Huang, Yunhao Chen, Xin Wang, Yixu Wang, **Xingjun Ma**, Yu-Gang Jiang
<br/>
ACM Multimedia (<b>MM</b>), Rio de Janeiro, Brazil, 2026.

<a href="https://arxiv.org/abs/2605.15203" target="_blank"><b>	
Agent4POI: Agentic context-conditioned affordance reasoning for Multimodal Point-of-Interest Recommendation
</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Jinze Wang, Yangchen Zeng, Tiehua Zhang, Lu Zhang, Yuze Liu, Yongchao Liu, **Xingjun Ma**, Zhu Sun
<br/>
ACM Multimedia (<b>MM</b>), Rio de Janeiro, Brazil, 2026.

<a href="https://arxiv.org/abs/2510.10932" target="_blank"><b>	
DropVLA: An Action-Level Backdoor Attack on Vision-Language-Action Models
</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Zonghuan Xu, Jiayu Li, Yunhan Zhao, Xiang Zheng, **Xingjun Ma**, Yu-Gang Jiang
<br/>
International Conference on Intelligent Robots and Systems (<b>IROS</b>), Pittsburgh, Pennsylvania, USA, 2026.

<a href="https://openreview.net/forum?id=bqgninCuh4#discussion" target="_blank"><b>	
Perturbation Effects on Robustness and Individual Fairness</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Xuran Li, Hao Xue, Peng Wu, **Xingjun Ma**, Zhen Zhang, Huaming Chen, Flora D. Salim<br/>
International Conference on Knowledge Discovery and Data Mining (<b>KDD</b>), Jeju Island, South Korea, 2026.

<a href="https://openreview.net/forum?id=UXbNXAJRCo" target="_blank"><b>	
FakeWorld 1.0: An Omni-modal Benchmark for Fake Media and Content</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Yifeng Gao, Yifan Ding, Li Wang, Feida Huang, Ye Sun, Yixu Wang, Xin Wang, Yutao Wu, Hanxun Huang, Yunhao Feng, Yingshui Tan, **Xingjun Ma**, Yu-Gang Jiang<br/>
International Conference on Machine Learning (<b>ICML</b>), Seoul, South Korea, 2026.

<a href="https://arxiv.org/abs/2601.21233" target="_blank"><b>	
Just Ask: Curious Code Agents Reveal System Prompts in Frontier LLMs
</b></a> <a href="https://github.com/x-zheng16/JustAsk" target="_blank"> [Code] </a> <a href="https://x-zheng16.github.io/System-Prompt-Open/" target="_blank"> [Project] </a> <br/>
Xiang Zheng, Yutao Wu, Hanxun Huang, Yige Li, **Xingjun Ma**, Bo Li, Yu-Gang Jiang, Cong Wang<br/>
International Conference on Machine Learning (<b>ICML</b>), Seoul, South Korea, 2026.

<a href="https://arxiv.org/abs/2602.12984" target="_blank"><b>	
SciAgentGym: Benchmarking Multi-Step Scientific Tool-Use in LLM Agents</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Yujiong Shen, Yajie Yang, Zhiheng Xi, Binze Hu, Huayu Sha, Qiyuan Peng, Jiazheng Zhang, Junlin Shang, Jixuan Huang, Yutao Fan, Jingqi Tong, Shihan Dou, Ming Zhang, LEI BAI, Zhenfei Yin, Tao Gui, **Xingjun Ma**, Qi Zhang, Xuanjing Huang, Yu-Gang Jiang <br/>
International Conference on Machine Learning (<b>ICML</b>), Seoul, South Korea, 2026.

<a href="" target="_blank"><b>	
AudioMosaic: Contrastive Masked Audio Representation Learning</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Hanxun Huang, Qizhou Wang, **Xingjun Ma**, Cihang Xie, Christopher Leckie, Sarah Monazam Erfani<br/>
International Conference on Machine Learning (<b>ICML</b>), Seoul, South Korea, 2026.

<a href="https://arxiv.org/abs/2605.20994" target="_blank"><b>	
Towards Context-Invariant Safety Alignment for Large Language Models</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Yixu Wang, Yang Yao, Xin Wang, Yifeng Gao, Yan Teng, **Xingjun Ma**, Yingchun Wang<br/>
International Conference on Machine Learning (<b>ICML</b>), Seoul, South Korea, 2026.

<a href="" target="_blank"><b>	
MESA: Improving MoE Safety Alignment via Decentralized Expertise</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Yitong Sun, Yao Huang, Teng Li, Ranjie Duan, Yichi Zhang, **Xingjun Ma**, Hui Xue, Xingxing Wei<br/>
International Conference on Machine Learning (<b>ICML</b>), Seoul, South Korea, 2026.

<a href="https://arxiv.org/abs/2603.01544" target="_blank"><b>	
RA-Det: Towards Universal Detection of AI-Generated Images via Robustness Asymmetry</b></a> <a href="https://github.com/dongdongunique/RA-Det" target="_blank"> [Code] </a> <br/>
Xinchang Wang, Yunhao Chen, Yuechen Zhang, Congcong Bian, Zihao Guo, **Xingjun Ma**, Hui Li <br/>
International Conference on Machine Learning (<b>ICML</b>), Seoul, South Korea, 2026.

<a href="https://aclanthology.org/2026.acl-long.199/" target="_blank"><b>	
Deliberative Searcher: Improving LLM Reliability via Reinforcement Learning with Constraints</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Zhenyun Yin, Shujie Wang, Xuhong Wang, **Xingjun Ma**, Yingchun Wang<br/>
Annual Meeting of the Association for Computational Linguistics (<b>ACL</b>), San Diego, California, USA, 2026. **[Main, Oral]**


<a href="https://arxiv.org/pdf/2601.04566" target="_blank"><b>	
BackdoorAgent: A Unified Framework for Backdoor Attacks on LLM-based Agents </b></a> <a href="https://github.com/Yunhao-Feng/BackdoorAgent" target="_blank"> [Code] </a> <br/>
Yunhao Feng, Yige Li, Yutao Wu, Yingshui Tan, Yanming Guo, Yifan Ding, Kun Zhai, **Xingjun Ma**, Yu-Gang Jiang<br/>
Annual Meeting of the Association for Computational Linguistics (<b>ACL</b>), San Diego, California, USA, 2026. **[Findings]**


<a href="https://arxiv.org/abs/2509.26100" target="_blank"><b>	
AgenticEval: Toward Agentic and Self-Evolving Safety Evaluation of Large Language Models</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Yixu Wang, Xin Wang, Yang Yao, Xinyuan Li, Xibang Yang, Yan Teng, **Xingjun Ma**, Yingchun Wang<br/>
Annual Meeting of the Association for Computational Linguistics (<b>ACL</b>), San Diego, California, USA, 2026. **[Findings]**


<a href="https://arxiv.org/abs/2603.02138" target="_blank"><b>	
OmniLottie: Generating Vector Animations via Parameterized Lottie Tokens</b></a> <a href="https://github.com/OpenVGLab/OmniLottie" target="_blank"> [Code] </a> <a href="https://openvglab.github.io/OmniLottie/" target="_blank"> [Project Page] </a> <a href="https://huggingface.co/papers/2603.02138" target="_blank"> [Hugging Face] </a><br/>
Yiying Yang, Wei Cheng, Sijin Chen, Honghao Fu, Xianfang Zeng, Yujun Cai, Gang YU, **Xingjun Ma**<br/>
IEEE/CVF Computer Vision and Pattern Recognition Conference (<b>CVPR</b>), Denver CO, USA, 2026.


<a href="https://arxiv.org/abs/2506.10047" target="_blank"><b>	
GenBreak: Red Teaming Text-to-Image Generation Using Large Language Models</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Zilong Wang, Xiang Zheng, Xiaosen Wang, Bo Wang, **Xingjun Ma**<br/>
IEEE/CVF Computer Vision and Pattern Recognition Conference (<b>CVPR</b>), Denver CO, USA, 2026.


<a href="https://arxiv.org/abs/2510.14975" target="_blank"><b> WithAnyone: Towards controllable and id consistent image generation</b></a> <a href="https://github.com/Doby-Xu/WithAnyone" target="_blank"> [Code] </a> <a href="https://doby-xu.github.io/WithAnyone/" target="_blank"> [Project] </a> <br/> 
Hengyuan Xu, Wei Cheng, Peng Xing, Yixiao Fang, Shuhan Wu, Rui Wang, Xianfang Zeng, Daxin Jiang, Gang Yu, **Xingjun Ma**, Yu-Gang Jiang<br/>
International Conference on Learning Representations (<b>ICLR</b>), Rio de Janeiro, Brazil, 2026.

<a href="https://arxiv.org/abs/2602.01025" target="_blank"><b> Toward Universal and Transferable Jailbreak Attacks on Vision-Language Models</b></a> <a href="https://github.com/kaiyuanCui/UltraBreak" target="_blank"> [Code] </a> <br/> 
Kaiyuan Cui, Yige Li, Yutao Wu, **Xingjun Ma**, Sarah Erfani, Christopher Leckie, Hanxun Huang<br/>
International Conference on Learning Representations (<b>ICLR</b>), Rio de Janeiro, Brazil, 2026.

<a href="https://arxiv.org/abs/2410.02467" target="_blank"><b>SIDE: Surrogate Conditional Data Extraction from Diffusion Models</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Yunhao Chen, Shujie Wang, Difan Zou, **Xingjun Ma**<br/>
Annual AAAI Conference on Artificial Intelligence (<b>AAAI</b>), Singapore, 2026.

<a href="https://arxiv.org/abs/2510.22242" target="_blank"><b> PaperAsk: A Benchmark for Reliability Evaluation of LLMs in Paper Search and Reading</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Yutao Wu, Xiao Liu, Yunhao Feng, Jiale Ding, **Xingjun Ma**<br/>
The Web Conference (<b>WWW</b>), Dubai, United Arab Emirates, 2026.

<a href="https://arxiv.org/abs/2512.16244" target="_blank"><b> Coarse-to-Fine Open-Set Graph Node Classification with Large Language Models</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Xueqi Ma, **Xingjun Ma**, Sarah Erfani, Danilo Mandic, James Bailey<br/>
Annual AAAI Conference on Artificial Intelligence (<b>AAAI</b>), Singapore, 2026.

<a href="https://arxiv.org/abs/2510.08012" target="_blank"><b>
Do We Really Need SFT? Prompt-as-Policy over Knowledge Graphs for Cold-start Next POI Recommendation</b></a> <br/>
Jinze Wang, Lu Zhang, Tiehua Zhang, Yiyang Cui, Zhishu Shen, Yuze Liu, **Xingjun Ma**, Jiong Jin <br/>
ACM International Conference on Information and Knowledge Management (<b>CIKM</b>), Rome, Italy, 2026.


<a href="https://arxiv.org/abs/2506.12706" target="_blank"><b> NAP-Tuning: Neural Augmented Prompt Tuning for Adversarially Robust Vision-Language Models</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Jiaming Zhang, Xin Wang, **Xingjun Ma**, Lingyu Qiu, Yu-Gang Jiang, Jitao Sang<br/>
IEEE Transactions on Pattern Analysis and Machine Intelligence (<b>TPAMI</b>), 2026.

<a href="https://arxiv.org/abs/2404.11888" target="_blank"><b> FedEGG: Federated Learning with Explicit Global Guidance</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Kun Zhai, Yifeng Gao, Yunhao Feng, Wei Gao, **Xingjun Ma**, Yu-Gang Jiang<br/>
Frontiers of Computer Science (<b>FCS</b>), 2026.

<a href="https://arxiv.org/abs/2410.08950" target="_blank"><b> On the Adversarial Transferability of Generalized "Skip Connections"</b></a> <a href="https://github.com/mo666666/SGM" target="_blank"> [Code] </a> <br/>
Yisen Wang, Yichuan Mo, Dongxian Wu, Mingjie Li, **Xingjun Ma**, Zhouchen Lin<br/>
IEEE Transactions on Pattern Analysis and Machine Intelligence (<b>TPAMI</b>), 2026.

<a href="https://arxiv.org/abs/2506.04302" target="_blank"><b> OpenRedRL: A Light-Weight Benchmark for Reinforcement Fine-Tuning-Based Red Teaming</b></a> <a href="https://github.com/x-zheng16/RedRFT" target="_blank"> [Code] </a> <br/>
Xiang Zheng, **Xingjun Ma**, Wei-Bin Lee, Cong Wang<br/>
Frontiers of Computer Science (<b>FCS</b>), 2026.

<a href="https://arxiv.org/abs/2509.12724" target="_blank"><b>	
Defense-to-attack: Bypassing weak defenses enables stronger jailbreaks in Vision-Language Models</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Yunhan Zhao, Xiang Zheng, **Xingjun Ma** <br/>
<b>Pattern Recognition</b>, 2026.

<a href="https://openreview.net/forum?id=ursw3nWq5K" target="_blank"><b>
Learnable Coreset Selection for Graph Active Learning</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Xueqi Ma, **Xingjun Ma**, Sarah Erfani, James Bailey <br/>
Transactions on Machine Learning Research (<b>TMLR</b>), 2026.


### 2025

<a href="https://arxiv.org/abs/2408.12798" target="_blank"><b>BackdoorLLM: A Comprehensive Benchmark for Backdoor Attacks and Defenses on Large Language Models</b></a> <a href="https://github.com/bboylyg/BackdoorLLM" target="_blank"> [Code] </a> <br/>
Yige Li, Hanxun Huang, Yunhan Zhao, **Xingjun Ma**, Jun Sun<br/>
Annual Conference on Neural Information Processing Systems (<b>NeurIPS</b>), San Diego, USA, 2025.

<a href="https://arxiv.org/abs/2505.11926" target="_blank"><b>SafeVid: Toward Safety Aligned Video Large Multimodal Models</b></a> <a href="https://huggingface.co/datasets/yxwang/SafeVid-350K" target="_blank"> [Dataset] </a> <br/>
Yixu Wang, Jiaxin Song, Yifeng Gao, Xin Wang, Yang Yao, Yan Teng, **Xingjun Ma**, Yingchun Wang, Yu-Gang Jiang<br/>
Annual Conference on Neural Information Processing Systems (<b>NeurIPS</b>), San Diego, USA, 2025.

<a href="https://arxiv.org/pdf/2504.06263" target="_blank"><b>	
OmniSVG: A Unified Scalable Vector Graphics Generation Model</b></a> <a href="https://github.com/OmniSVG/OmniSVG" target="_blank"> [Code] </a> <a href="https://omnisvg.github.io/" target="_blank"> [Project Page] </a> <a href="https://huggingface.co/OmniSVG" target="_blank"> [Hugging Face] </a><br/>
Yiying Yang, Wei Cheng, Sijin Chen, Xianfang Zeng, Fukun Yin, Jiaxu Zhang, Liao Wang, Gang YU, **Xingjun Ma**, Yu-Gang Jiang<br/>
Annual Conference on Neural Information Processing Systems (<b>NeurIPS</b>), San Diego, USA, 2025.

<a href="https://arxiv.org/abs/2505.18812" target="_blank"><b>SAMA: Towards Multi-Turn Referential Grounded Video Chat with Large Language Models</b></a> <br/>
Ye Sun, Hao Zhang, Henghui Ding, Tiehua Zhang, **Xingjun Ma**, Yu-Gang Jiang<br/>
Annual Conference on Neural Information Processing Systems (<b>NeurIPS</b>), San Diego, USA, 2025.

<a href="https://arxiv.org/abs/2505.19610" target="_blank"><b>JailBound: Jailbreaking Internal Safety Boundaries of Vision-Language Models</b></a> <br/>
Jiaxin Song, Yixu Wang, Jie Li, Xuan Tong, Rui Yu, Yan Teng, **Xingjun Ma**, Yingchun Wang<br/>
Annual Conference on Neural Information Processing Systems (<b>NeurIPS</b>), San Diego, USA, 2025.


<a href="https://arxiv.org/abs/2502.05206" target="_blank"><b>Safety at Scale: A Comprehensive Survey of Large Model and Agent Safety</b></a><a href="https://github.com/xingjunm/Awesome-Large-Model-Safety" target="_blank"> [Code] </a><br/>
**Xingjun Ma**, Yifeng Gao, Yixu Wang, Ruofan Wang, Xin Wang, Ye Sun, Yifan Ding, Hengyuan Xu, Yunhao Chen, Yunhan Zhao, Hanxun Huang, Yige Li, Yutao Wu, Jiaming Zhang, Xiang Zheng, Yang Bai, Zuxuan Wu, Xipeng Qiu, Jingfeng Zhang, Yiming Li, Xudong Han, Haonan Li, Jun Sun, Cong Wang, Jindong Gu, Baoyuan Wu, Siheng Chen, Tianwei Zhang, Yang Liu, Mingming Gong, Tongliang Liu, Shirui Pan, Cihang Xie, Tianyu Pang, Yinpeng Dong, Ruoxi Jia, Yang Zhang, Shiqing Ma, Xiangyu Zhang, Neil Gong, Chaowei Xiao, Sarah Erfani, Tim Baldwin, Bo Li, Masashi Sugiyama, Dacheng Tao, James Bailey, Yu-Gang Jiang. <b>Foundations and Trends® in Privacy and Security</b>, 2025.

<a href="https://arxiv.org/abs/2401.15295" target="_blank"><b>Shortcuts Everywhere and Nowhere: Exploring Multi-Trigger Backdoor Attacks</b></a><a href="https://github.com/bboylyg/Multi-Trigger-Backdoor-Attacks" target="_blank"> [Code] </a><br/>
Yige Li, Jiabo He, Hanxun Huang, Jun Sun, **Xingjun Ma**, Yu-Gang Jiang<br/>
IEEE Transactions on Dependable and Secure Computing (<b>TDSC</b>), 2025.

<a href="https://arxiv.org/abs/2412.01440" target="_blank"><b>BadPatch: Diffusion-Based Generation of Physical Adversarial Patches</b></a><a href="https://github.com/Wwangb/BadPatch" target="_blank"> [Code] </a> <a href="https://github.com/Wwangb/AdvT-shirt-1K" target="_blank"> [AdvT-shirt-1K Dataset] </a> <br/>
Zhixiang Wang, **Xingjun Ma**, Yu-Gang Jiang<br/>International Conference on Computer Vision (<b>ICCV</b>) Workshop Findings, Honolulu, Hawai'i, 2025.

<a href="https://arxiv.org/abs/2411.00827" target="_blank"><b>IDEATOR: Jailbreaking and Benchmarking Large Vision-Language Models Using Themselves</b></a><a href="https://github.com/roywang021/IDEATOR" target="_blank"> [Code] </a> <br/>
Ruofan Wang, Juncheng Li, Yixu Wang, Bo Wang, Xiaosen Wang, Yan Teng, Yingchun Wang, **Xingjun Ma**, Yu-Gang Jiang<br/>International Conference on Computer Vision (<b>ICCV</b>), Honolulu, Hawai'i, 2025.

<a href="https://arxiv.org/abs/2501.01425" target="_blank"><b>	
Free-Form Motion Control: Controlling the 6D Poses of Camera and Objects in Video Generation</b></a><a href="" target="_blank"> [Code] </a> <br/>
Xincheng Shuai, Henghui Ding, Zhenyuan Qin, Hao Luo, **Xingjun Ma**, Dacheng Tao<br/>International Conference on Computer Vision (<b>ICCV</b>), Honolulu, Hawai'i, 2025.

<a href="" target="_blank"><b>StolenLoRA: Exploring LoRA Extraction Attacks via Synthetic Data</b></a><a href="" target="_blank"> [Code] </a> <br/>
Yixu Wang, Yan Teng, Yingchun Wang, **Xingjun Ma**<br/>International Conference on Computer Vision (<b>ICCV</b>), Honolulu, Hawai'i, 2025.

<a href="https://arxiv.org/abs/2508.03091" target="_blank"><b>T2UE: Generating Unlearnable Examples from Text Descriptions</b></a><a href="" target="_blank"> [Code] </a> <br/>
**Xingjun Ma**, Hanxun Huang, Tianwei Song, Ye Sun, Yifeng Gao, Yu-Gang Jiang<br/> ACM Multimedia (<b>MM</b>), Dublin, Ireland, 2025.

<a href="" target="_blank"><b>FedAPT: Federated Adversarial Prompt Tuning for Vision-Language Models</b></a><a href="" target="_blank"> [Code] </a> <br/>
Kun Zhai, Siheng Chen, **Xingjun Ma**, Yu-Gang Jiang<br/> ACM Multimedia (<b>MM</b>), Dublin, Ireland, 2025.

<a href="https://arxiv.org/abs/2505.22067" target="_blank"><b>From Failures to Fixes: LLM-Driven Scenario Repair for Self-Evolving Autonomous Driving</b></a><a href="https://xinyuxia97.github.io/SERA/" target="_blank"> [Code] </a> <br/>
Xinyu Xia, **Xingjun Ma**, Yunfeng hu, Qu Ting, Hong Chen, Xun Gong<br/> ACM Multimedia (<b>MM</b>), Dublin, Ireland, 2025.

<a href="https://arxiv.org/abs/2506.20103" target="_blank"><b>BrokenVideos: A Benchmark Dataset for Fine-Grained Artifact Localization in AI-Generated Videos</b></a><a href="https://broken-video-detection-datetsets.github.io/Broken-Video-Detection-Datasets.github.io/" target="_blank"> [Code] </a> <br/>
Jiahao Lin, Weixuan Peng, Bojia Zi, Yifeng Gao, Xianbiao Qi, **Xingjun Ma**, Yu-Gang Jiang<br/>Dataset Track, ACM Multimedia (<b>MM</b>), Dublin, Ireland, 2025.

<a href="https://arxiv.org/abs/2505.05528" target="_blank"><b>X-Transfer Attacks: Towards Super Transferable Adversarial Attacks on CLIP</b></a><a href="https://github.com/HanxunH/XTransferBench" target="_blank"> [Code] </a> <a href="https://hanxunh.github.io/XTransferBench" target="_blank"> [Project] </a> <a href="https://huggingface.co/spaces/hanxunh/XTransferBench-UAP-Linf" target="_blank"> [HuggingFace demo] </a> <br/>
Hanxun Huang, Sarah Erfani, Yige Li, **Xingjun Ma**, James Bailey<br/>International Conference on Machine Learning (<b>ICML</b>), Vancouver, Canada, 2025.

<a href="https://arxiv.org/abs/2411.15210" target="_blank"><b>Towards Million-Scale Adversarial Robustness Evaluation With Stronger Individual Attacks</b></a><a href="https://opentai.org/VisionSafety" target="_blank"> [Project] </a> <br/>
Yong Xie, Weijie Zheng, Hanxun Huang, Guangnan Ye, **Xingjun Ma**<br/>IEEE/CVF Computer Vision and Pattern Recognition Conference (<b>CVPR</b>), Nashville TN, 2025.


<a href="https://arxiv.org/abs/2411.13136" target="_blank"><b>TAPT: Test-Time Adversarial Prompt Tuning for Robust Inference in Vision-Language Models</b></a><a href="https://github.com/xinwong/TAPT" target="_blank"> [Code] </a> <br/>
Xin Wang, Kai Chen, Jiaming Zhang, Jingjing Chen, **Xingjun Ma**<br/>IEEE/CVF Computer Vision and Pattern Recognition Conference (<b>CVPR</b>), Nashville TN, 2025.


<a href="https://arxiv.org/abs/2410.05346" target="_blank"><b>AnyAttack: Towards Large-scale Self-supervised Adversarial Attacks on Vision-Language Models</b></a><a href="https://github.com/jiamingzhang94/AnyAttack" target="_blank"> [Code] </a> <a href="https://jiamingzhang94.github.io/anyattack/" target="_blank"> [Project] </a> <br/>
Jiaming Zhang, Junhong Ye, **Xingjun Ma**, Yige Li, Yunfan Yang, Yunhao Chen, Jitao Sang, Dit-Yan Yeung<br/>IEEE/CVF Computer Vision and Pattern Recognition Conference (<b>CVPR</b>), Nashville TN, 2025.

<a href="https://arxiv.org/abs/2410.20971" target="_blank"><b>BlueSuffix: Reinforced Blue Teaming for Vision-Language Models Against Jailbreak Attacks</b></a><a href="https://github.com/Vinsonzyh/BlueSuffix" target="_blank"> [Code] </a> <br/>
Yunhan Zhao, Xiang Zheng, Lin Luo, Yige Li, **Xingjun Ma**, Yu-Gang Jiang<br/>
International Conference on Learning Representations (<b>ICLR</b>), Singapore, 2025.

<a href="https://arxiv.org/abs/2502.01385" target="_blank"><b>Detecting Backdoor Samples in Contrastive Language Image Pretraining</b></a><a href="https://github.com/HanxunH/Detect-CLIP-Backdoor-Samples" target="_blank"> [Code] </a> <a href="https://hanxunh.github.io/Detect-CLIP-Backdoor-Samples" target="_blank"> [Project] </a> <br/>
Hanxun Huang, Sarah Erfani, Yige Li, **Xingjun Ma**, James Bailey<br/>
International Conference on Learning Representations (<b>ICLR</b>), Singapore, 2025.

<a href="https://arxiv.org/abs/2501.01106" target="_blank"><b>AIM: Additional Image Guided Generation of Transferable Adversarial Attacks</b></a> <br/>
Teng Li, **Xingjun Ma**, Yu-Gang Jiang<br/>
AAAI Conference on Artificial Intelligence (<b>AAAI</b>), Philadelphia, USA, 2025.

<a href="https://arxiv.org/abs/2501.02997" target="_blank"><b>CALM: Curiosity-Driven Auditing for Large Language Models</b></a><a href="https://github.com/x-zheng16/CALM" target="_blank"> [Code] </a> <br/>
Xiang Zheng, Longxiang WANG, Yi Liu, **Xingjun Ma**, Chao Shen, Cong Wang<br/>
AAAI Conference on Artificial Intelligence (<b>AAAI</b>), Philadelphia, USA, 2025.

<a href="https://arxiv.org/pdf/2501.01090" target="_blank"><b>	
HoneypotNet: Backdoor Attacks Against Model Extraction</b></a> <br/>
Yixu Wang, Tianle Gu, Yan Teng, Yingchun Wang, **Xingjun Ma**<br/>
AAAI Conference on Artificial Intelligence (<b>AAAI</b>), Philadelphia, USA, 2025.

<a href="" target="_blank"><b>	
MMFair: Fair Learning via Min-Min Optimization</b></a> <br/>
Kejie Fang, Kun Zhai, **Xingjun Ma**<br/>
International Conference on Information and Knowledge Management (<b>CIKM</b>), Seoul, Korea, 2025.

<a href="https://openreview.net/forum?id=GZMwvlXG9y" target="_blank"><b>	
Optimizing Cross-Client Domain Coverage for Federated Instruction Tuning of Large Language Models</b></a> <br/>
Zezhou Wang, Yaxin Du, **Xingjun Ma**, Yu-Gang Jiang, Zhuzhong Qian, Siheng Chen<br/>
<b>EMNLP 2025 Findings</b>, Suzhou, China, 2025.

<a href="https://arxiv.org/abs/2307.03411" target="_blank"><b>	
Learning from Heterogeneity: A Dynamic Learning Framework for Hypergraphs</b></a> <a href="https://github.com/paperCodeEric/LFH" target="_blank"> [Code] </a> <br/>
Tiehua Zhang, Yuze Liu, Zhishu Shen, **Xingjun Ma**, Peng Qi, Zhijun Ding, Jiong Jin<br/>
IEEE Transactions on Artificial Intelligence (<b>TAI</b>), To appear in 2025.


### 2024

<a href="https://arxiv.org/abs/2410.09909v1" target="_blank"><b>UnSeg: One Universal Unlearnable Example Generator is Enough against All Image Segmentation</b></a> <br/>
Ye Sun, Hao Zhang, Tiehua Zhang, **Xingjun Ma**, Yu-Gang Jiang<br/>
Annual Conference on Neural Information Processing Systems (<b>NeurIPS</b>), Vancouver, Canada, 2024.


<a href="https://arxiv.org/abs/2405.16285" target="_blank"><b>ModelLock: Locking Your Model With a Spell</b></a> <a href="" target="_blank"> [Code] </a> <br/>
Yifeng Gao, Yuhua Sun, **Xingjun Ma**, Zuxuan Wu, Yu-Gang Jiang<br/>
ACM Multimedia (<b>MM</b>), Melbourne, Australia, 2024.

<a href="https://arxiv.org/abs/2405.17894" target="_blank"><b>White-box Multimodal Jailbreaks Against Large Vision-Language Models</b></a> <a href="" target="_blank"> [Code] </a><br/>
Ruofan Wang, **Xingjun Ma**, Hanxu Zhou, Chuanjun Ji, Guangnan Ye, Yu-Gang Jiang<br/> ACM Multimedia (<b>MM</b>), Melbourne, Australia, 2024.

<a href="https://www.arxiv.org/abs/2408.01978" target="_blank"><b>AdvQDet: Detecting Query-Based Adversarial Attacks with Adversarial Contrastive Prompt Tuning</b></a> <a href="https://github.com/xinwong/AdvQDet" target="_blank"> [Code] </a><br/>
Xin Wang, Kai Chen, **Xingjun Ma**, Zhineng Chen, Jingjing Chen, Yu-Gang Jiang<br/>
 ACM Multimedia (<b>MM</b>), Melbourne, Australia, 2024.


<a href="https://arxiv.org/abs/2310.16400" target="_blank"><b>Fuse Your Latents: Video Editing with Multi-source Latent Diffusion Models</b></a> <a href="https://github.com/lutianyi0603/fuse_your_latents" target="_blank"> [Code] </a><br/>
Tianyi Lu, Xing Zhang, Jiaxi Gu, Hang Xu, Renjing Pei, Songcen Xu, **Xingjun Ma**, Zuxuan Wu<br/>
 ACM Multimedia (<b>MM</b>), Melbourne, Australia, 2024.

<a href="https://arxiv.org/abs/2311.11261" target="_blank"><b>Adversarial Prompt Tuning for Vision-Language Models</b></a> <a href="https://github.com/jiamingzhang94/Adversarial-Prompt-Tuning" target="_blank"> [Code] </a> <br/>
Jiaming Zhang, **Xingjun Ma**, Xin Wang, Lingyu Qiu, Jiaqi Wang, Yu-Gang Jiang, Jitao Sang<br/>
European Conference on Computer Vision (<b>ECCV</b>), MiCo Milano, Italy, 2024.

<a href="https://arxiv.org/abs/2407.09247" target="_blank"><b>Constrained Intrinsic Motivation for Reinforcement Learning</b></a> <a href="https://github.com/x-zheng16/CIM" target="_blank"> [Code] </a><br/>
Xiang Zheng, **Xingjun Ma**, Chao Shen, Cong Wang<br/>
International Joint Conference on Artificial Intelligence (<b>IJCAI</b>), Jeju, Korea, 2024.

<a href="https://arxiv.org/abs/2305.02605" target="_blank"><b>Toward Evaluating Robustness of Reinforcement Learning with Adversarial Policy</b></a> <a href="https://github.com/x-zheng16/IMAP" target="_blank"> [Code] </a> <br/>
Xiang Zheng, **Xingjun Ma**, Shengjie Wang, Xinyu Wang, Chao Shen, Cong Wang<br/>
International Conference on Dependable Systems and Networks (<b>DSN</b>), Brisbane, Australia, 2024.

<a href="https://arxiv.org/abs/2205.12709" target="_blank"><b>VeriFi: Towards Verifiable Federated Unlearning</b></a> <br/>
Xiangshan Gao, **Xingjun Ma**, Jingyi Wang, Youcheng Sun, Bo Li, Shouling Ji, Peng Cheng, Jiming Chen<br/>
IEEE Transactions on Dependable and Secure Computing (<b>TDSC</b>), 2024. (<span style="color:red;font-weight:bold">Best Paper Runner-up</span>)

<a href="https://arxiv.org/abs/2311.05915" target="_blank"><b>Fake Alignment: Are LLMs Really Aligned Well?</b></a> <br/>
Yixu Wang, Yan Teng, Kexin Huang, Chengqi Lyu, Songyang Zhang, Wenwei Zhang, **Xingjun Ma**, Yu-Gang Jiang, Yu Qiao, Yingchun Wang<br/>
Annual Conference of the North American Chapter of the Association for Computational Linguistics (<b>NAACL</b>), Mexico City, Mexico, 2024.


<a href="https://openreview.net/pdf?id=oZyAqjAjJW" target="_blank"><b>LDReg: Local Dimensionality Regularized Self-Supervised Learning</b></a> <a href="https://github.com/HanxunH/LDReg" target="_blank"> [Code] </a> <br/>
Hanxun Huang, Ricardo J. G. B. Campello, Sarah M. Erfani, **Xingjun Ma**, Michael E. Houle, James Bailey<br/>
International Conference on Learning Representations (<b>ICLR</b>), Vienna, Austria, 2024.

<a href="https://arxiv.org/abs/2402.02028" target="_blank"><b>Unlearnable Examples For Time Series</b></a> <br/>
Yujing Jiang, **Xingjun Ma**, Sarah Monazam Erfani and James Bailey<br/>
Pacific-Asia Conference on Knowledge Discovery and Data Mining (<b>PAKDD</b>), 2024.

### 2023

<a href="https://arxiv.org/abs/2305.14876" target="_blank"><b>Reconstructive Neuron Pruning for Backdoor Defense</b></a> <a href="https://github.com/bboylyg/RNP" target="_blank"> [Code] </a> <br/>
Yige Li, Xixiang Lyu, **Xingjun Ma**, Nodens Koren, Lingjuan Lyu, Bo Li, Yu-Gang Jiang<br/>
International Conference on Machine Learning (<b>ICML</b>), Hawaii, USA, 2023.

<a href="https://arxiv.org/abs/2301.01217" target="_blank"><b>Unlearnable Clusters: Towards Label-agnostic Unlearnable Examples</b></a> <a href="https://github.com/jiamingzhang94/Unlearnable-Clusters" target="_blank"> [Code] </a> <br/>
Jiaming Zhang, **Xingjun Ma**, Qi Yi, Jitao Sang, Yu-Gang Jiang, Yaowei Wang, Changsheng Xu<br/>
IEEE/CVF Computer Vision and Pattern Recognition Conference (<b>CVPR</b>), Vancouver, Canada, 2023.

<a href="https://arxiv.org/abs/2301.10908" target="_blank"><b>Distilling Cognitive Backdoor Patterns within an Image</b></a> <a href="https://github.com/HanxunH/CognitiveDistillation" target="_blank"> [Code] </a> <br/>
Hanxun Huang, **Xingjun Ma**, Sarah M. Erfani, James Bailey<br/>
International Conference on Learning Representations (<b>ICLR</b>), Kigali, Rwanda, 2023.

<a href="https://openreview.net/forum?id=-htnolWDLvP" target="_blank"><b>Transferable Unlearnable Examples</b></a><a href="https://github.com/renjie3/TUE" target="_blank"> [Code] </a><br/>
Jie Ren, Han Xu, Yuxuan Wan, **Xingjun Ma**, Lichao Sun, Jiliang Tang<br/>
International Conference on Learning Representations (<b>ICLR</b>), Kigali, Rwanda, 2023.

<a href="" target="_blank"><b>On the Importance of Spatial Relations for Few-shot Action Recognition</b></a><a href="" target="_blank"> [Code] </a><br/>
Yilun Zhang, Yuqian Fu, **Xingjun Ma**, Lizhe Qi, Jingjing Chen, Zuxuan Wu, Yu-Gang Jiang<br/>
ACM Multimedia (<b>MM</b>), Ottawa, Canada, 2023.

<a href="https://arxiv.org/abs/2211.07915" target="_blank"><b>Backdoor Attacks on Time Series: A Generative Approach</b><a href="https://github.com/yujingmarkjiang/Time_Series_Backdoor_Attack" target="_blank"> [Code] </a></a><br/>
Yujing Jiang, **Xingjun Ma**, Sarah M. Erfani, James Bailey<br/>
IEEE Conference on Secure and Trustworthy Machine Learning (<b>SaTML</b>), 2023.

<a href="https://www.sciencedirect.com/science/article/abs/pii/S0306437923000819" target="_blank"><b>Relationships between tail entropies and local intrinsic dimensionality and their use for estimation and feature representation</b></a> <br/>
James Bailey, Michael E. Houle, **Xingjun Ma**<br/>
<b>Information Systems</b> (2023): 102245.

<a href="https://arxiv.org/abs/2006.13726.pdf" target="_blank"><b>Imbalanced Gradients: A Subtle Cause of Overestimated Adversarial Robustness</b></a><a href="https://github.com/HanxunH/MDAttack" target="_blank"> [Code] </a><br/>
**Xingjun Ma**<sup>*</sup>, Linxi Jiang<sup>*</sup>, Hanxun Huang, Zejia Weng, James Bailey, Yu-Gang Jiang<br/> 
<b>Machine Learning</b> (2023): 1-26.

<a href="https://ieeexplore.ieee.org/abstract/document/10237306" target="_blank"><b>Query-efficient Black-box Adversarial Attacks on Automatic Speech Recognition</b></a><a href="" target="_blank"> [Code] </a><br/>
Chuxuan Tong, Xi Zheng, Jianhua Li, **Xingjun Ma**, Longxiang Gao, Yong Xiang<br/> 
To appear in IEEE/ACM Transactions on Audio, Speech and Language Processing (<b>TASLP</b>).



### 2022

<a href="https://www.mdpi.com/1099-4300/24/9/1220/pdf" target="_blank"><b>Local Intrinsic Dimensionality, Entropy and Statistical Divergences</b></a><br/>
James Bailey, Michael E. Houle, **Xingjun Ma**<br/>
<b>Entropy</b> 24(9), 1220, 2022.

<a href="https://openreview.net/pdf?id=qSV5CuSaK_a" target="_blank"><b>Few-Shot Backdoor Attacks on Visual Object Tracking</b></a>
<a href="https://github.com/HXZhong1997/FSBA" target="_blank"> [Code] </a><br/>
Yiming Li, Haoxiang Zhong, **Xingjun Ma**, Yong Jiang, Shu-Tao Xia<br/>
International Conference on Learning Representations (<b>ICLR</b>), 2022.

<a href="https://arxiv.org/abs/2205.14926" target="_blank"><b>CalFAT: Calibrated Federated Adversarial Training with Label Skewness</b></a><br/>
Chen Chen, Yuchen Liu, **Xingjun Ma**, Lingjuan Lyu<br/>
Advances in Neural Information Processing Systems (<b>NeurIPS</b>), 2022.

<a href="https://arxiv.org/abs/2112.05588" target="_blank"><b>Copy, Right? A Testing Framework for Copyright Protection of Deep Learning Models</b></a> <a href="https://github.com/Testing4AI/DeepJudge" target="_blank"> [Code] </a><br/>
Jialuo Chen, Jingyi Wang, Tinglan Peng, Youcheng Sun, Peng Cheng, Shouling Ji, **Xingjun Ma**, Bo Li, Dawn Song <br/>
IEEE Symposium on Security and Privacy (<b>Oakland</b>), 2022.

<a href="https://arxiv.org/abs/2207.05641" target="_blank"><b>Backdoor Attacks on Crowd Counting</b></a>
<a href="https://github.com/Nathangitlab/Backdoor-Attacks-on-Crowd-Counting" target="_blank"> [Code] </a><br/>
Yuhua Sun, Tailai Zhang, **Xingjun Ma**, Pan Zhou, Jian Lou, Zichuan Xu, Xing Di, Yu Cheng, Lichao Sun<br/>
ACM Multimedia (<b>MM</b>), 2022.

<a href="https://arxiv.org/abs/2210.09545" target="_blank"><b>Fine-mixing: Mitigating Backdoors in Fine-tuned Language Models</b></a><br/>
Zhiyuan Zhang, Lingjuan Lyu, **Xingjun Ma**, Chenguang Wang, Xu Sun <br/>
The 2022 Conference on Empirical Methods on Natural Language Processing (<b>EMNLP</b>), 2022.

<a href="https://arxiv.org/abs/2012.06337" target="_blank"><b>Privacy and Robustness in Federated Learning: Attacks and Defenses</b></a><br/>
Lingjuan Lyu, Han Yu, **Xingjun Ma**, Chen Chen, Lichao Sun, Jun Zhao, Qiang Yang, Philip Yu <br/>
IEEE Transactions on Neural Networks and Learning Systems (<b>TNNLS</b>), 2022.

<a href="https://dl.acm.org/doi/pdf/10.1145/3582573" target="_blank"><b>QuoTe: Quality-oriented Testing for Deep Learning Systems</b></a><br/>Jialuo Chen, Jingyi Wang*, **Xingjun Ma**, Youcheng Sun, Jun Sun, Peixin Zhang and Peng Cheng <br/>
ACM Transactions on Software Engineering and Methodology (<b>TOSEM</b>) (accepted in 2022).

<a href="https://link.springer.com/article/10.1007/s10853-022-07793-6" target="_blank"><b>Machine learning guided alloy design of high-temperature NiTiHf shape memory alloys</b></a><br/>
Udesh M.H.U. Kankanamge, Johannes Reiner, **Xingjun Ma**, Santiago Corujeira Gallo, Wei Xu <br/>
<b>Journal of Materials Science</b>. (<span style="color:red;font-weight:bold">2022 Robert W. Cahn Best Paper Award</span>)


### 2021

<a href="https://arxiv.org/abs/2110.03825" target="_blank"><b>Exploring Architectural Ingredients of Adversarially Robust Deep Neural Networks</b></a><a href="https://github.com/HanxunH/RobustWRN" target="_blank"> [Code] </a><br/>
Hanxun Huang, Yisen Wang, Sarah M. Erfani, Quanquan Gu, James Bailey, **Xingjun Ma**<br/>
Advances in Neural Information Processing Systems (<b>NeurIPS</b>), 2021.

<a href="http://arxiv.org/abs/2110.13675" target="_blank"><b>Alpha-IoU: A Family of Power Intersection over Union Losses for Bounding Box Regression</b></a><a href="https://github.com/Jacobi93/Alpha-IoU" target="_blank"> [Code] </a><br/>
Jiabo He, Sarah M. Erfani, **Xingjun Ma**, James Bailey, Ying Chi, Xian-Sheng Hua<br/>
Advances in Neural Information Processing Systems (<b>NeurIPS</b>), 2021.

<a href="https://arxiv.org/abs/2110.11571" target="_blank"><b>Anti-Backdoor Learning: Training Clean Models on Poisoned Data</b></a><a href="https://github.com/bboylyg/ABL" target="_blank"> [Code] </a><br/>
Yige Li, Xixiang Lyu, Nodens Koren, Lingjuan Lyu, Bo Li, **Xingjun Ma**<br/>
Advances in Neural Information Processing Systems (<b>NeurIPS</b>), 2021.

<a href="https://openreview.net/forum?id=yRfsADObu18" target="_blank"><b>Gradient Driven Rewards to Guarantee Fairness in Collaborative Machine Learning</b></a><a href="" target="_blank"> [Code] </a><br/>
Xinyi Xu, Lingjuan Lyu, **Xingjun Ma**, Chenglin Miao, Chuan-Sheng Foo, Kian H. Low<br/>
Advances in Neural Information Processing Systems (<b>NeurIPS</b>), 2021.

<a href="https://openreview.net/forum?id=iAmZUo0DxC0" target="_blank"><b>Unlearnable Examples: Making Personal Data Unexploitable</b> </a>
<a href="https://github.com/HanxunH/Unlearnable-Examples" target="_blank"> [Code] </a> <a href="https://hanxunh.github.io/Unlearnable-Examples/" target="_blank"> [Webpage] </a><br/>
Hanxun Huang, **Xingjun Ma**, Sarah M. Erfani, James Bailey, Yisen Wang<br/>
International Conference on Learning Representations (<b>ICLR</b>), 2021. (<span style="color:red;font-weight:bold">Spotlight, top 4%</span>)<br/>
Press: <a href="https://www.technologyreview.com/2021/05/05/1024613/stop-ai-recognizing-your-face-selfies-machine-learning-facial-recognition-clearview" target="_blank">MIT Technology Review</a>, <a href="https://pursuit.unimelb.edu.au/articles/blocking-ai-to-keep-your-personal-data-your-own" target="_blank">PURSUIT</a>, <a href="https://gadgets.ndtv.com/science/news/facial-recognition-ai-spoofing-for-selfies-fawkes-lowkey-image-cloaking-adversarial-attacks-2439007" target="_blank">Gadgets 360</a>

<a href="https://openreview.net/forum?id=9l0K4OM-oXE" target="_blank"><b>Neural Attention Distillation: Erasing Backdoor Triggers from Deep Neural Networks</b></a>
<a href="https://github.com/bboylyg/NAD" target="_blank"> [Code] </a><br/>
Yige Li, Xixiang Lyu, Nodens Koren, Lingjuan Lyu, Bo Li, **Xingjun Ma**<br/>
International Conference on Learning Representations (<b>ICLR</b>), 2021.

<a href="https://openreview.net/forum?id=zQTezqCCtNx" target="_blank"><b>Improving Adversarial Robustness via Channel-wise Activation Suppressing</b></a>
<a href="https://github.com/bymavis/CAS_ICLR2021" target="_blank"> [Code] </a><br/>
Yang Bai, Yuyuan Zeng, Yong Jiang, Shu-Tao Xia, **Xingjun Ma**, Yisen Wang<br/>
International Conference on Learning Representations (<b>ICLR</b>), 2021. (<span style="color:red;font-weight:bold">Spotlight, top 4%</span>)

<a href="https://arxiv.org/abs/2108.07969" target="_blank"><b>Revisiting Adversarial Robustness Distillation: Robust Soft Labels Make Student Better</b></a>
<a href="https://github.com/zibojia/RSLAD" target="_blank"> [Code] </a><br/>
Bojia Zi<sup>*</sup>, Shihao Zhao<sup>*</sup>, **Xingjun Ma**, Yu-Gang Jiang<br/>
International Conference on Computer Vision (<b>ICCV</b>), 2021.

<a href="https://arxiv.org/abs/2106.01532" target="_blank"><b>Noise Doesn’t Lie: Towards Universal Detection of Deep Inpainting </b></a><br/>
Ang Li, Qiuhong Ke, **Xingjun Ma**, Haiqin Weng, Zhiyuan Zong, Feng Xue, Rui Zhang<br/>
International Joint Conference on Artificial Intelligence (<b>IJCAI</b>), 2021.

<a href="/assets/files/LID_tail_entropy_SISAP2021.pdf" target="_blank"><b>Relationships between Local Intrinsic Dimensionality and Tail Entropy</b></a>
<a href="https://www.youtube.com/watch?v=4pG0_wRfd5g&list=PLU6sx10A4i3YMTkRclcn8HEXPYWZrLJdo" target="_blank"> [Video] </a><br/>
James Bailey, Michael Houle, **Xingjun Ma**<br/>
International Conference on Similarity Search and Applications (<b>SISAP</b>), Dortmund, Germany, 2021. (<span style="color:red;font-weight:bold">Best Paper Award</span>)

<a href="https://arxiv.org/abs/2102.05913.pdf" target="_blank"><b>RobOT: Robustness-Oriented Testing for Deep Learning Systems</b></a>
<a href="https://github.com/SmallkeyChen/RobOT" target="_blank"> [Tookit] </a><br/>
Jingyi Wang, Jialuo Chen, Youcheng Sun, **Xingjun Ma**, Dongxia Wang, Jun Sun, Peng Cheng<br/>
International Conference on Software Engineering (<b>ICSE</b>), 2021.

<a href="https://arxiv.org/abs/2106.03355" target="_blank"><b>Sub-trajectory Similarity Join with Obfuscation</b></a><br/>
Yanchuan Chang, Jianzhong Qi, Egemen Tanin, **Xingjun Ma**, Hanan Samet<br/>
International Conference on Scientific and Statistical Database Management (<b>SSDBM</b>), 2021. (<span style="color:red;font-weight:bold">Best Paper Runner-up Award</span>)

<a href="http://arxiv.org/abs/2110.15082" target="_blank"><b>SpineOne: A One-Stage Detection Framework for Degenerative Discs and Vertebrae</b></a><a href="" target="_blank"> </a><br/>
Jiabo He, Wei Liu, Yu Wang, **Xingjun Ma**, Xian-Sheng Hua <br/>
IEEE International Conference on Bioinformatics and Biomedicine (<b>BIBM</b>), 2021.

<a href="https://arxiv.org/abs/2104.10377.pdf" target="_blank"><b>Dual Head Adversarial Training</b></a> 
<a href="https://github.com/yujingmarkjiang/Dual-Head-Adversarial-Training" target="_blank"> [Code]</a> <br/>
Yujing Jiang, **Xingjun Ma**, Sarah M. Erfani, James Bailey<br/>
International Joint Conference on Neural Networks (<b>IJCNN</b>), 2021.

<a href="https://arxiv.org/abs/2101.00336.pdf" target="_blank"><b>Neural Architecture Search via Combinatorial Multi-Armed Bandit</b></a><br/>
Hanxun Huang, **Xingjun Ma**, Sarah M. Erfani, James Bailey<br/>
International Joint Conference on Neural Networks (<b>IJCNN</b>), 2021.
 
<a href=""><b>Federated Learning with Extreme Label Skew: A Data Extension Approach</b></a><br/>
Saheed Tijani, **Xingjun Ma**, Frank Jiang, Robin Doss<br/>
International Joint Conference on Neural Networks (<b>IJCNN</b>), 2021.
 
<a href=""><b>Microwave Link Failures Prediction via LSTM-based Feature Fusion Network</b></a><br/>
Zichan Ruan, Shuiqiao Yang, Lei Pan, **Xingjun Ma**, Wei Luo, Marthie Grobler<br/>
International Joint Conference on Neural Networks (<b>IJCNN</b>), 2021.

<a href="https://arxiv.org/abs/2102.07277.pdf" target="_blank"><b>Anomaly Detection for Scenario-based Insider Activities using CGAN Augmented Data</b></a> <br/>
R G Gayathri, Atul Sajjanhar, Yong Xiang, **Xingjun Ma**<br/>
International Conference on Trust, Security and Privacy in Computing and Communications (<b>TrustCom</b>), 2021.

<a href="https://arxiv.org/abs/2107.07677" target="_blank"><b>ECG-Adv-GAN: Detecting ECG Adversarial Examples with Conditional Generative Adversarial Networks</b></a> <br/>
Khondker Fariha Hossain, Sharif Amit Kamran, Alireza Tavakkoli, Lei Pan, **Xingjun Ma**, Sutharshan Rajasegarar, Chandan Karmaker<br/>
International Conference on Machine Learning and Applications (<b>ICMLA</b>), 2021.

<a href="" target="_blank"><b>Exploring the Vulnerability of Natural Language Processing Models via Universal Adversarial Texts</b></a><a href="" target="_blank"> </a><br/>
Xinzhe Li, Ming Liu, **Xingjun Ma**, Longxiang Gao <br/>
Australasian Language Technology Association Workshop (<b>ALTA</b>), 2021.

<a href="https://link.springer.com/article/10.1007/s00405-021-06633-8" target="_blank"><b>Surgical approach to the facial recess influences the acceptable trajectory of cochlear implantation electrodes</b></a><br/>
Bridget Copson, Sudanthi Wijewickrema, **Xingjun Ma**, Yun Zhou, Jean-Marc Gerard, Stephen O’Leary <br/>
European Archives of Oto-Rhino-Laryngology, 1-11, 2021.

<!-- <a href="https://arxiv.org/abs/2101.06898.pdf" target="_blank"><b>What Do Deep Nets Learn? Class-wise Patterns Revealed in the Input Space</b></a>
<a href="https://github.com/ShihaoZhaoZSH/what-do-deep-nets-learn" target="_blank"> [Code] </a><br/>
Shihao Zhao, **Xingjun Ma**, Yisen Wang, James Bailey, Bo Li, Yu-Gang Jiang<br/>
arXiv preprint. -->

<!-- <a href="https://arxiv.org/abs/2102.08081.pdf" target="_blank"><b>A Lazy Approach for Efficient Index Learning</b> </a><br/>
Guanli Liu, Lars Kulik, **Xingjun Ma**, Jianzhong Qi<br/>
arXiv preprint.

<a href="https://arxiv.org/abs/2101.06704.pdf" target="_blank"><b>Adversarial Interaction Attack: Fooling AI to Misinterpret Human Intentions</b></a><br/>
Nodens Koren, Qiuhong Ke, Yisen Wang, James Bailey, **Xingjun Ma**<br/>
arXiv preprint. -->

### 2020

<a href="https://arxiv.org/abs/2006.13554" target="_blank"><b>Normalized Loss Functions for Deep Learning with Noisy Labels</b></a>
<a href="https://github.com/HanxunHuangLemonBear/Active-Passive-Losses" target="_blank"> [Code] </a><br/>
**Xingjun Ma**<sup>*</sup>, Hanxun Huang<sup>*</sup>, Yisen Wang, Simone Romano, Sarah M. Erfani, James Bailey<br/>
International Conference on Machine Learning (<b>ICML</b>), 2020.
 
<a href="https://openreview.net/forum?id=rklOg6EFwS" target="_blank"><b>Improving Adversarial Robustness Requires Revisiting Misclassified Examples</b></a>
<a href="https://github.com/YisenWang/MART" target="_blank"> [Code] </a><br/>
Yisen Wang*, Difan Zou*, Jinfeng Yi, James Bailey, **Xingjun Ma**, Quanquan Gu <br/>
International Conference on Learning Representations (<b>ICLR</b>), 2020.

<a href="https://openreview.net/forum?id=BJlRs34Fvr" target="_blank"><b>Skip Connections Matter: on the Transferability of Adversarial Examples Generated with ResNets</b></a>
<a href="https://github.com/csdongxian/skip-connections-matter" target="_blank"> [Code] </a><br/>
Dongxian Wu, Yisen Wang, Shu-Tao Xia, James Bailey, **Xingjun Ma**<br/>
International Conference on Learning Representations (<b>ICLR</b>), 2020. (<span style="color:red;font-weight:bold">Spotlight, top 4%</span>)

<a href="https://arxiv.org/abs/1907.10456.pdf" target="_blank"><b>Understanding Adversarial Attacks on Deep Learning Based Medical Image Analysis Systems</b></a><a href="https://github.com/zzdyyy/Understanding-Adversarial-Attacks-MIA" target="_blank"> [Code] </a><br/>
**Xingjun Ma**<sup>*</sup>, Yuhao Niu<sup>*</sup>, Lin Gu, Yisen Wang, Yitian Zhao, James Bailey, Feng Lu<br/>
Pattern Recognition (<b>PR</b>), 110, 2021, 107332. (accepted in 2020)<br/> 
Press: <a href="https://www.rsipvision.com/ComputerVisionNews-2020October/4/" target="_blank"> Computer Vision News</a>

<a href="https://arxiv.org/abs/2003.03030" target="_blank"><b>Clean-Label Backdoor Attacks on Video Recognition Models</b></a>
<a href="https://github.com/ShihaoZhaoZSH/Video-Backdoor-Attack" target="_blank"> [Code] </a><br/>
Shihao Zhao, **Xingjun Ma**, Xiang Zheng, James Bailey, Jingjing Chen, Yu-Gang Jiang<br/>
IEEE/CVF Conference on Computer Vision and Pattern Recognition (<b>CVPR</b>), 2020.

<a href="https://arxiv.org/abs/2003.08757" target="_blank"><b>Adversarial Camouflage: Hiding Physical-World Attacks with Natural Styles</b></a>
<a href="https://github.com/RjDuan/AdvCam-Hide-Adv-with-Natural-Styles" target="_blank"> [Code] </a><br/>
Ranjie Duan, **Xingjun Ma**, Yisen Wang, James Bailey, Kai Qin, Yun Yang<br/>
IEEE/CVF Conference on Computer Vision and Pattern Recognition (<b>CVPR</b>), 2020.

<a href="https://arxiv.org/abs/2101.01456" target="_blank"><b>WildDeepfake: A Challenging Real-World Dataset for Deepfake Detection</b></a>
<a href="https://github.com/deepfakeinthewild/deepfake-in-the-wild" target="_blank"> [Dataset/Code] </a><br/>
Bojia Zi, Jingjing Chen, Minghao Chang, **Xingjun Ma**, Yu-Gang Jiang<br/>
ACM International Conference on Multimedia (<b>ACM MM<b>), 2020.

<a href="https://arxiv.org/abs/2007.02343" target="_blank"><b>Reflection Backdoor: A Natural Backdoor Attack on Deep Neural Networks</b></a>
<a href="https://github.com/DreamtaleCore/Refool" target="_blank"> [Code] </a>
<br/>
Yunfei Liu, **Xingjun Ma**, James Bailey, Feng Lu<br/>
European Conference on Computer Vision (<b>ECCV<b>), 2020.

<a href="https://arxiv.org/abs/2009.05721" target="_blank"><b>Short-Term and Long-Term Context Aggregation Network for Video Inpainting</b></a>
<br/>
Ang Li, Shanshan Zhao, **Xingjun Ma**, Mingming Gong, Jianzhong Qi, Rui Zhang, Dacheng Tao, Ramamohanarao Kotagiri<br/>
European Conference on Computer Vision (<b>ECCV<b>), 2020. (<span style="color:red;font-weight:bold">Spotlight, top 5%</span>)

<a href="https://link.springer.com/chapter/10.1007/978-3-030-52237-7_24" target="_blank"><b>Transfer of Automated Performance Feedback Models to Different Specimens in Virtual Reality Temporal Bone Surgery</b></a> <br/>
Jesslyn Lamtara, Nathan Hanegbi, Benjamin Talks, Sudanthi Wijewickrema, **Xingjun Ma**, Patorn Piromchai, James Bailey, Stephen O'Leary<br/>
International Conference on Artificial Intelligence in Education (<b>AIED<b>), 2020.

<a href="https://arxiv.org/abs/1906.01167" target="_blank"><b>Towards Fair and Privacy-Preserving Federated Deep Models</b></a>
<a href="https://github.com/lingjuanlv/FPPDL" target="_blank"> [Code] </a>
<a href="https://medium.com/@llv_9800/how-to-ensure-collaborative-fairness-and-privacy-in-decentralized-federated-learning-721e37595604" target="_blank"> [Medium] </a>
<a href="https://www.youtube.com/watch?v=d_Z_YmBvmno" target="_blank"> [Youtube] </a>
<br/>
Lingjuan Lyu, Jiangshan Yu, Karthik Nandakumar, Yitong Li, **Xingjun Ma**, Jiong Jin, Han Yu, Kee Siong Ng<br/>
IEEE Transactions on Parallel and Distributed Systems (<b>TPDS</b>). (accepted in 2020)

<a href="https://arxiv.org/abs/2007.09370" target="_blank"><b>How to Democratise and Protect AI: Fair and Differentially Private Decentralised Deep Learning</b></a><br/>
Lingjuan Lyu, Yitong Li, Karthik, Nandakumar, Jiangshan Yu, **Xingjun Ma**<br/>
IEEE Transactions on Dependable and Secure Computing (<b>TDSC</b>). (accepted in 2020)


### 2019

<a href="http://proceedings.mlr.press/v97/wang19i/wang19i.pdf" target="_blank"><b>On the Convergence and Robustness of Adversarial Training</b></a>
<a href="https://github.com/YisenWang/dynamic_adv_training" target="_blank"> [Code] </a><br/>
Yisen Wang<sup>*</sup>, **Xingjun Ma**<sup>*</sup>, James Bailey, Jinfeng Yi, Bowen Zhou, Quanquan Gu<br/>
International Conference on Machine Learning (<b>ICML</b>), Long Beach, USA, 2019. (<span style="color:red;font-weight:bold">Long talk, top 3%</span>)

<a href="https://arxiv.org/abs/1908.06112" target="_blank"><b>Symmetric Cross Entropy for Robust Learning with Noisy Labels</b></a>
<a href="https://github.com/YisenWang/symmetric_cross_entropy_for_noisy_labels" target="_blank"> [Code] </a><br/>
Yisen Wang<sup>*</sup>, **Xingjun Ma**<sup>*</sup>, Zaiyi Chen, Yuan Luo, Jinfeng Yi, James Bailey<br/>
International Conference on Computer Vision (<b>ICCV<b>), Seoul, Korea, 2019.
 
<a href="https://arxiv.org/abs/1904.05181" target="_blank"><b>Black-box Adversarial Attacks on Video Recognition Models</b></a>
<a href="https://github.com/Jack-lx-jiang/VBAD" target="_blank"> [Code] </a><br/>
Linxi Jiang<sup>*</sup>, **Xingjun Ma**<sup>*</sup>, Shaoxiang Chen, James Bailey, Yu-Gang Jiang<br/>
ACM International Conference on Multimedia (<b>ACM MM<b>), Nice, France, 2019.

<a href="http://arxiv.org/abs/1908.00211" target="_blank"><b>Generative Image Inpainting with Submanifold Alignment</b></a><br/>
Ang Li, Jianzhong Qi, Rui Zhang, **Xingjun Ma**, Ramamohanarao Kotagiri<br/>
International Joint Conference on Artificial Intelligence (<b>IJCAI<b>), Macao, China, 2019.

<a href="https://people.eng.unimelb.edu.au/baileyj/papers/KAIS2019.pdf" target="_blank"><b>Exploiting Patterns to Explain Individual Predictions</b></a><br/>
Yunzhe Jia, James Bailey, Ramamohanarao Kotagiri, Christopher Leckie, **Xingjun Ma**<br/>
Knowledge and Information Systems (<b>KAIS<b>). (accepted in 2019)

<!--<b>Quality Evaluation of GANs Using Cross Local Intrinsic Dimensionality</b> 
<a href="https://arxiv.org/abs/1905.00643"> [Paper] </a><br/>
Sukarna Barua, **Xingjun Ma**, Sarah M. Erfani, Michael E. Houle, James Bailey<br/>
arxiv preprint. -->

<!--
<a href="https://minerva-access.unimelb.edu.au/bitstream/handle/11343/219680/Machine%20Learning%20with%20Adversarial%20Perturbations%20and%20Noisy%20Labels.pdf?sequence=1&isAllowed=y">Machine Learning with Adversarial Perturbations and Noisy Labels</a><br/>
**Xingjun Ma**, PhD thesis.
-->

### 2018

<a href="https://arxiv.org/pdf/1801.02613.pdf" target="_blank"><b>Characterizing Adversarial Subspaces Using Local Intrinsic Dimensionality</b></a>
<a href="https://github.com/xingjunm/lid_adversarial_subspace_detection" target="_blank"> [Code] </a><br/>
**Xingjun Ma**, Bo Li, Yisen Wang, Sarah M. Erfani, Sudanthi Wijewickrema,  Grant Schoenebeck, Dawn Song, Michael E. Houle, James Bailey<br/>
International Conference on Learning Representations (<b>ICLR</b>), Vancouver, BC, Canada, 2018, (<span style="color:red;font-weight:bold">Oral, top 2%</span>)

<a href="https://arxiv.org/pdf/1806.02612.pdf" target="_blank"><b>Dimensionality-Driven Learning with Noisy Labels</b></a>
<a href="https://github.com/xingjunm/dimensionality-driven-learning" target="_blank"> [Code] </a><br/>
**Xingjun Ma**<sup>*</sup>, Yisen Wang<sup>*</sup>, Michael E. Houle, Shuo Zhou, Sarah M. Erfani, Shu-Tao Xia, Sudanthi Wijewickrema, James Bailey<br/>
International Conference on Machine Learning (<b>ICML</b>), Stockholm, Sweden, 2018. (<span style="color:red;font-weight:bold">Long talk, top 4%</span>)
 
<a href="https://arxiv.org/pdf/1804.00092.pdf" target="_blank"><b>Iterative Learning with Open-set Noisy Labels</b></a><br/>
Yisen Wang, Weiyang Liu, **Xingjun Ma**, James Bailey,  Hongyuan  Zha, Le Song, Shu-Tao Xia<br/>
IEEE/CVF Conference on Computer Vision and Pattern Recognition (<b>CVPR</b>), Salt Lake City, Utah, USA, 2018. (<span style="color:red;font-weight:bold">Spotlight, top 6%</span>)
 
<a href="https://people.eng.unimelb.edu.au/baileyj/papers/AIED2018.pdf" target="_blank"><b>Providing Automated Real-Time Technical Feedback for Virtual Reality Based Surgical Training: Is the Simpler the Better?</b></a><br/>
Sudanthi Wijewickrema, **Xingjun Ma**, Patorn Piromchai, Robert Briggs, James Bailey, Gregor Kennedy, Stephen O'Leary<br/>
International Conference on Artificial Intelligence in Education (<b>AIED</b>), London, UK, 2018
 
<a href="https://people.eng.unimelb.edu.au/baileyj/papers/CBMS_2018_final.pdf" target="_blank"><b>Development and Validation of a Virtual Reality Tutor to Teach Clinically Oriented Surgical Anatomy of the Ear</b></a><br/>
Sudanthi Wijewickrema, Bridget Copson, **Xingjun Ma**, Robert Briggs, James Bailey, Gregor Kennedy, Stephen O'Leary<br/> 
IEEE International Symposium on Computer-Based Medical Systems (<b>CBMS</b>), 2018

### 2017

<a href="https://arxiv.org/abs/1706.10036" target="_blank"><b>Providing Effective Real-time Feedback in Simulation-based Surgical Training</b></a><br/>
**Xingjun Ma**, Sudanthi Wijewickrema, Yun Zhou, Shuo Zhou, Stephen O'Leary, James Bailey<br/> 
International Conference on Medical Image Computing and Computer Assisted Intervention (<b>MICCAI</b>), Quebec City, Canada, 2017.

<a href="https://arxiv.org/pdf/1703.01460.pdf" target="_blank"><b>Adversarial Generation of Real-time Feedback with Neural Networks for Simulation-based Training</b></a><br/>
**Xingjun Ma**, Sudanthi Wijewickrema, Shuo Zhou, Yun Zhou, Zakaria Mhammedi, Stephen O'Leary, James Bailey.<br/>
International Joint Conference on Artificial Intelligence (<b>IJCAI</b>), Melbourne, Australia, 2017. (<span style="color:red;font-weight:bold">Oral</span>)

<!-- ### 2017

<a href="https://arxiv.org/pdf/1703.01460.pdf" target="_blank"><b>Adversarial Generation of Real-time Feedback with Neural Networks for Simulation-based Training</b></a><br/>
**Xingjun Ma**, Sudanthi Wijewickrema, Shuo Zhou, Yun Zhou, Zakaria Mhammedi, Stephen O'Leary, James Bailey.<br/>
International Joint Conference on Artificial Intelligence (<b>IJCAI</b>), Melbourne, Australia, 2017. (<span style="color:red;font-weight:bold">Oral</span>)

<a href="http://people.eng.unimelb.edu.au/baileyj/papers/AAAI_17_CR.pdf" target="_blank"><b>Unbiased Multivariate Correlation Analysis</b></a><br/>
Yisen Wang, Simone Romano, Nguyen Xuan Vinh, James Bailey, **Xingjun Ma**, Shu-Tao Xia<br/> 
AAAI Conference on Artificial Intelligence (<b>AAAI</b>), San Francisco, USA, 2017. (<span style="color:red;font-weight:bold">Oral</span>)
 
<a href="https://arxiv.org/abs/1706.10036" target="_blank"><b>Providing Effective Real-time Feedback in Simulation-based Surgical Training</b></a><br/>
**Xingjun Ma**, Sudanthi Wijewickrema, Yun Zhou, Shuo Zhou, Stephen O'Leary, James Bailey<br/> 
International Conference on Medical Image Computing and Computer Assisted Intervention (<b>MICCAI</b>), Quebec City, Canada, 2017.
 
<a href="http://people.eng.unimelb.edu.au/baileyj/papers/cbms-2017-2.pdf" target="_blank"><b>Simulation for Training Cochlear Implant Electrode Insertion</b></a><br/>
**Xingjun Ma**, Sudanthi Wijewickremay, Yun Zhou, Bridget Copson, James Bailey, Gregor Kennedy, Stephen O'Leary<br/>
IEEE International Symposium on Computer-Based Medical Systems (<b>CBMS</b>), Thessaloniki, Greece, 2017
 
<a href="http://people.eng.unimelb.edu.au/baileyj/papers/cbms-2017-1.pdf" target="_blank"><b>Design and Evaluation of a Virtual Reality Simulation Module for Training Advanced Temporal Bone Surgery</b></a><br/>
Sudanthi Wijewickremay, Bridget Copson, Yun Zhou, **Xingjun Ma**, Robert Briggs, James Bailey, Gregor Kennedy, Stephen O'Leary<br/>
IEEE International Symposium on Computer-Based Medical Systems (<b>CBMS</b>), Thessaloniki, Greece, 2017


<a href="https://arxiv.org/pdf/1705.04683.pdf">Feedback Techniques in Computer-Based Simulation Training: A Survey</a><br/>
Sudanthi Wijewickrema, **Xingjun Ma**, James Bailey, Gregor Kennedy and Stephen O'Leary<br/>
arXiv preprint. 


### 2016

<b>Finding Influentials in Twitter: A Temporal Influence Ranking Model</b> 
<a href="https://arxiv.org/pdf/1703.01468.pdf" target="_blank"> [Paper] </a><br/>
**Xingjun Ma**, Chunping Li, James Bailey, Sudanthi Wijewickrema<br/>
The Australasian Data Mining Conference (<b>AusDM</b>), Canberra, Australia, 2016 -->

